<?php
/* Config */
include 'db_connect.php'; 
$message = "";

try {
    $pdo = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password); 
    $userCount = $pdo->query("SELECT COUNT(*) FROM Account WHERE Role = 'Student'")->fetchColumn();
    $adminCount = $pdo->query("SELECT COUNT(*) FROM Account WHERE Role = 'Admin' OR Role = 'Staff'")->fetchColumn();
    $currentBookings = $pdo->query("SELECT COUNT(*) FROM Booking WHERE Returned = 0")->fetchColumn(); 
    $totalBookings = $pdo->query("SELECT COUNT(*) FROM Booking")->fetchColumn(); 
    
    $overdueCount = 0;

    $stmt = $pdo->query("SELECT TimeOut FROM Booking WHERE Returned = 0"); 
    $activeBookings = $stmt->fetchAll(PDO::FETCH_ASSOC);

    foreach ($activeBookings as $b) {
        $borrowDate = new DateTime($b['TimeOut']);
        $today = new DateTime();
        $interval = $borrowDate->diff($today);
        
        if ($interval->days > 14) {
            $overdueCount++;
        }
    }

} catch (PDOException $e) { 

    $message = "Database Error: " . $e->getMessage(); 
} 
?>
<!DOCTYPE html>
<html>
<head>
    <title>System stats</title>
</head>
<body style="margin: 0;">
    
    <?php include 'header.php'; ?>

    <div style="padding: 20px;">
        <h1>Bookhub Statistics</h1> 
        
        <?php if(!empty($message)): ?>
            <p style="color: red;"><?php echo $message; ?></p>
        <?php endif; ?>

        <table border="1" style="border-collapse: collapse; width: 100%; max-width: 400px; background: white;">
            <tr style="background-color: #a0ac90; color: white;">
                <th style="padding: 8px; text-align: left;">Category</th>
                <th style="padding: 8px; text-align: left;">Count</th>
            </tr>
            <tr>
                <td style="padding: 8px;">Number of Users</td>
                <td style="padding: 8px;"><?php echo $userCount; ?></td> 
            </tr>
            <tr>
                <td style="padding: 8px;">Number of Admins/Staff</td>
                <td style="padding: 8px;"><?php echo $adminCount; ?></td> 
            </tr>
            <tr>
                <td style="padding: 8px;">Active Bookings</td>
                <td style="padding: 8px;"><?php echo $currentBookings; ?></td> 
            </tr>
            <tr>
                <td style="padding: 8px;">Total Bookings</td>
                <td style="padding: 8px;"><?php echo $totalBookings; ?></td> 
            </tr>
            <tr>
                <td style="padding: 8px;">Total Overdue Books</td>
                <td style="padding: 8px;"><?php echo $overdueCount; ?></td> 
            </tr>
        </table>
    </div>
</body>
</html>