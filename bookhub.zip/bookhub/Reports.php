<?php
session_start();

if (!isset($_SESSION['Role']) || ($_SESSION['Role'] !== 'Admin' && $_SESSION['Role'] !== 'Staff')) {
    header("Location: login.php");
    exit();
}

include 'db_connect.php'; 
$message = "";

try {
    $pdo = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password); 
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $userCount = $pdo->query("SELECT COUNT(*) FROM Account WHERE Role = 'Student'")->fetchColumn();
    $adminCount = $pdo->query("SELECT COUNT(*) FROM Account WHERE Role = 'Admin' OR Role = 'Staff'")->fetchColumn(); //get all the column data
    $currentBookings = $pdo->query("SELECT COUNT(*) FROM Booking WHERE Returned = 0")->fetchColumn(); 
    $totalBookings = $pdo->query("SELECT COUNT(*) FROM Booking")->fetchColumn(); 
    
    $overdueCount = 0;
    $stmt = $pdo->query("SELECT TimeOut FROM Booking WHERE Returned = 0"); 
    $activeBookings = $stmt->fetchAll(PDO::FETCH_ASSOC);

    foreach ($activeBookings as $b) {
        $borrowDate = new DateTime($b['TimeOut']);
        $today = new DateTime();
        $interval = $borrowDate->diff($today);
        
        if ($interval->days > 14) {
            $overdueCount++;
        }
    }

} catch (PDOException $e) { 
    $message = "Database Error: " . $e->getMessage(); 
} 

include 'header.php'; 
?>
<!DOCTYPE html>
<html>
<head>
    <title>System Statistics - BookHub</title>
    <style>
        body { font-family: 'Segoe UI', sans-serif; background-color: #ede6df; margin: 0; }
        .container { max-width: 800px; margin: 40px auto; background: white; padding: 30px; border-radius: 8px; box-shadow: 0 4px 6px rgba(0,0,0,0.1); }
        .stats-table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        .stats-table th, .stats-table td { padding: 12px; border: 1px solid #ddd; text-align: left; }
        .stats-table th { background-color: #a0ac90; color: white; }
    </style>
</head>
<body>
    <div class="container">
        
        <?php if(!empty($message)): ?>
            <p style="color: red;"><?php echo htmlspecialchars($message); ?></p>
        <?php endif; ?>

        <table class="stats-table">
            <thead>
                <tr>
                    <th>Category</th>
                    <th>Count</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>Registered Students</td>
                    <td><?php echo (int)$userCount; ?></td> 
                </tr>
                <tr>
                    <td>Library Staff / Admins</td> <!-- columns -->
                    <td><?php echo (int)$adminCount; ?></td> 
                </tr>
                <tr>
                    <td>Active Bookings</td>
                    <td><?php echo (int)$currentBookings; ?></td> 
                </tr>
                <tr>
                    <td>Overdue Items (> 14 Days)</td>
                    <td><?php echo (int)$overdueCount; ?></td> 
                </tr>
                <tr>
                    <td>Lifetime Total Bookings</td>
                    <td><?php echo (int)$totalBookings; ?></td> 
                </tr>
            </tbody>
        </table>
    </div>
</body>
</html>