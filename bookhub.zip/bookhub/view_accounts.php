<?php 
session_start(); 

if (!isset($_SESSION['Role']) || ($_SESSION['Role'] !== 'Admin' && $_SESSION['Role'] !== 'Staff')) {
    header("Location: login.php"); //connect
    exit();
}

include 'header.php'; 
include 'db_connect.php'; 
?>
<!DOCTYPE html>
<html>
<head>
    <title>Manage Accounts - BookHub</title>
    <style>
        body { font-family: 'Segoe UI', sans-serif; background-color: #ede6df; margin: 0; }
        .container { max-width: 1000px; margin: 40px auto; background: white; padding: 30px; border-radius: 8px; box-shadow: 0 4px 6px rgba(0,0,0,0.1); }
        h2 { color: #4a4a4a; border-bottom: 2px solid #a0ac90; padding-bottom: 10px; margin-bottom: 20px; }
        table { width: 100%; border-collapse: collapse; background: white; }
        th { background-color: #a0ac90; color: white; padding: 12px; text-align: left; }
        td { padding: 12px; border-bottom: 1px solid #ddd; color: #555; }
        tr:hover { background-color: #f9f9f9; }
        .role-badge { padding: 4px 8px; border-radius: 4px; font-size: 12px; font-weight: bold; background: #eee; }
    </style>
</head>
<body>
    <div class="container">
        <h2>Manage User Accounts</h2>
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Full Name</th>
                    <th>Email Address</th>
                    <th>Access Level</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $sql = "SELECT UserID, FirstName, LastName, Email, Role FROM Account";
                $result = $conn->query($sql);
                if ($result && $result->num_rows > 0) {
                    while($row = $result->fetch_assoc()) {
                        echo "<tr>
                                <td>".$row['UserID']."</td>
                                <td>".htmlspecialchars($row['FirstName'])." ".htmlspecialchars($row['LastName'])."</td>
                                <td>".htmlspecialchars($row['Email'])."</td>
                                <td><span class='role-badge'>".htmlspecialchars($row['Role'])."</span></td>
                              </tr>";
                    }
                }
                ?>
            </tbody>
        </table>
    </div>
</body>
</html>