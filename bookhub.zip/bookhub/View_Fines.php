<?php
/* Config */
include 'db_connect.php'; 
$fines_data = [];

try {
    $pdo = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    
    /* Get the bookings not returned */
    $query = "SELECT users.name, bookings.borrow_date 
              FROM bookings 
              JOIN users ON bookings.user_id = users.id 
              WHERE bookings.return_status = 'borrowed'";
              
    $stmt = $pdo->query($query);
    $bookings = $stmt->fetchAll(PDO::FETCH_ASSOC);

    /* calculate fines */
    foreach ($bookings as $b) {
        $borrowDate = new DateTime($b['borrow_date']);
        $today = new DateTime();
        $interval = $borrowDate->diff($today);
        $daysBorrowed = $interval->days;

        /* check if overdue */
        if ($daysBorrowed > 14) {
            $overdueDays = $daysBorrowed - 14;
            $fineAmount = $overdueDays * 0.50; /* 50P per day */

            $fines_data[] = [
                'name' => $b['name'],
                'amount' => $fineAmount
            ];
        }
    }
} catch (PDOException $e) { 
    $error = "Data error."; 
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Current Fines</title>
</head>
<body style="margin: 0;">

    <?php include 'header.php'; ?>

    <div style="padding: 20px;">
        <h1>Member Fines</h1>
        
        <table border="1" style="border-collapse: collapse; width: 100%; max-width: 400px;"> 
            <tr>
                <th style="padding: 8px;">Name</th>
                <th style="padding: 8px;">Amount</th>
            </tr>
            <?php if (empty($fines_data)): ?>
                <tr><td colspan="2" style="padding: 8px;">No current fines</td></tr> <?php else: ?>
                <?php foreach ($fines_data as $f): ?>
                    <tr>
                        <td style="padding: 8px;"><?php echo htmlspecialchars($f['name']); ?></td>
                        <td style="padding: 8px;">£<?php echo number_format($f['amount'], 2); ?></td> 
                    </tr> 
                <?php endforeach; ?>
            <?php endif; ?>
        </table>
    </div>

</body>
</html>