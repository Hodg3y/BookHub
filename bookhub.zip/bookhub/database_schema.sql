CREATE TABLE bookdescribed (
    ISBN VARCHAR(20) PRIMARY KEY,
    Title VARCHAR(100),
    Author VARCHAR(100),
    Published INT,
    Genre VARCHAR(50),
    Description VARCHAR(1000)
);

CREATE TABLE account (
    UserID INT PRIMARY KEY AUTO_INCREMENT, -- Correctly added
    FirstName VARCHAR(50),
    LastName VARCHAR(50),
    Password VARCHAR(100),
    Email VARCHAR(100),
    Role VARCHAR(20)
);

CREATE TABLE inventory (
    BookID INT PRIMARY KEY,
    ISBN VARCHAR(20),
    Status VARCHAR(50),
    FOREIGN KEY (ISBN) REFERENCES BookDescribed(ISBN)
);

CREATE TABLE booking (
    BookingID INT PRIMARY KEY AUTO_INCREMENT, -- Correctly added to fix the '0' index error
    UserID INT,
    BookID INT,
    TimeOut DATE, -- Correctly updated from INT to DATE
    TimeDueIn DATE, -- Correctly updated from INT to DATE
    Returned BOOLEAN,
    FOREIGN KEY (UserID) REFERENCES Account(UserID),
    FOREIGN KEY (BookID) REFERENCES Inventory(BookID)
);

-- ACCOUNT DATA
-- Note: Removed manual UserID 1, 2, 3 to let AUTO_INCREMENT work properly
INSERT INTO account (FirstName, LastName, Password, Email, Role) VALUES
('John', 'Smith', 'pass1', 'JohnSmith@gmail.com', 'Student'),
('Jane', 'Smith', 'pass2', 'JaneSmith@gmail.com', 'Staff'),
('Alex', 'Jones', 'pass3', 'AlexJones@gmail.com', 'Student');

-- BOOK DESCRIPTIONS
INSERT INTO bookdescribed (ISBN, Title, Author, Published, Genre, Description) VALUES
('ISBN-001', 'The Great Gatsby', 'F. Scott Fitzgerald', 1925, 'Classic', 'A story of the Jazz Age.'),
('ISBN-002', '1984', 'George Orwell', 1949, 'Dystopian', 'Big Brother is watching.'),
('ISBN-003', 'The Hobbit', 'J.R.R. Tolkien', 1937, 'Fantasy', 'A hobbits journey.'),
('ISBN-004', 'Brave New World', 'Aldous Huxley', 1932, 'Dystopian', 'A programmed society.'),
('ISBN-005', 'Hamlet', 'William Shakespeare', 1603, 'Tragedy', 'The Prince of Denmark.'),
('ISBN-006', 'Moby Dick', 'Herman Melville', 1851, 'Adventure', 'The hunt for the white whale.');

-- INVENTORY
INSERT INTO inventory (BookID, ISBN, Status) VALUES
(101, 'ISBN-001', 'Checked In'),
(102, 'ISBN-002', 'Checked In'),
(103, 'ISBN-003', 'Checked In'),
(104, 'ISBN-004', 'Checked In'),
(105, 'ISBN-005', 'Checked In'),
(106, 'ISBN-006', 'Checked In');