<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "bookhub_db";

try {
    $setup_pdo = new PDO("mysql:host=$servername", $username, $password);
    $setup_pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $setup_pdo->exec("CREATE DATABASE IF NOT EXISTS `$dbname`");
    $setup_pdo->exec("USE `$dbname`");

    $tableExists = $setup_pdo->query("SHOW TABLES LIKE 'Account'")->rowCount() > 0;

    if (!$tableExists) {
        $sql_file = 'database_schema.sql';
        if (file_exists($sql_file)) {
            $sql = file_get_contents($sql_file);
            $setup_pdo->exec($sql);
        } else {
            die("Critical Error: 'database_schema.sql' is missing. Cannot initialize the system.");
        }
    }
} catch (PDOException $e) {
    die("System Initialization Failed: " . $e->getMessage());
}

mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
try {
    $conn = new mysqli($servername, $username, $password, $dbname);
    $conn->set_charset("utf8mb4");
} catch (Exception $e) {
    die("Connection failed: " . $e->getMessage());
}
?>