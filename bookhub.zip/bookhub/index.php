<?php
include 'db_connect.php'; 
$bookCount = 0; 
try {
    $pdo = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password); //connect 
    $bookCount = $pdo->query("SELECT COUNT(*) FROM BookDescribed")->fetchColumn();
} catch (PDOException $e) { $message = "Database Error"; }
include 'header.php'; 
?>
<!DOCTYPE html>
<html>
<head>
    <title>Bookhub - Home</title>
    <style>
        body { font-family: 'Segoe UI', sans-serif; background-color: #ede6df; margin: 0; }
        .container { max-width: 900px; margin: 40px auto; padding: 20px; }
        .stats-card { background-color: white; border: 2px solid #a0ac90; border-radius: 12px; padding: 30px; text-align: center; width: 280px; box-shadow: 0 4px 10px rgba(0,0,0,0.05); }
        .stats-card h3 { font-size: 50px; margin: 10px 0; color: #a0ac90; }
        .actions { display: flex; gap: 20px; margin-top: 30px; }
        .btn { text-decoration: none; padding: 15px 30px; border-radius: 8px; font-weight: bold; display: flex; align-items: center; gap: 10px; transition: 0.2s; }
        .btn-primary { background-color: #a0ac90; color: white; }
        .btn-secondary { background-color: white; color: #a0ac90; border: 2px solid #a0ac90; }
        .btn:hover { opacity: 0.9; transform: scale(1.02); }
    </style>
</head>
<body>
    <main class="container">
        <h1 style="color: #4a4a4a;">Library Dashboard</h1>
        <div class="stats-card">
            <p style="color: #666; margin: 0;">Total Cataloged Books</p>
            <h3><?php echo $bookCount; ?></h3>
        </div>
        <h2 style="color: #4a4a4a; margin-top: 50px;">Quick Actions</h2>
        <div class="actions">
            <a href="take_book.php" class="btn btn-primary"><i class="fa-solid fa-book-bookmark"></i> Take Out a Book</a>
            <a href="search_books.php" class="btn btn-secondary"><i class="fa-solid fa-magnifying-glass"></i> Search Catalog</a>
        </div>
    </main>
</body>
</html>