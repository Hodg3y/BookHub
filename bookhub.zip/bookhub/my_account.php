<?php 
session_start(); 
if (!isset($_SESSION['user_id'])) { header("Location: login.php"); exit(); } 
include 'header.php'; include 'db_connect.php'; 
$user_id = $_SESSION['user_id'];
$user_name = $_SESSION['name'];
?>
<!DOCTYPE html>
<html>
<head>
    <title>My Account - BookHub</title>
    <style>
        body { font-family: 'Segoe UI', sans-serif; background-color: #ede6df; margin: 0; }
        .container { max-width: 1000px; margin: 40px auto; background: white; padding: 35px; border-radius: 12px; box-shadow: 0 4px 15px rgba(0,0,0,0.05); }
        .profile-header { display: flex; justify-content: space-between; align-items: center; border-bottom: 2px solid #a0ac90; padding-bottom: 15px; margin-bottom: 30px; }
        table { width: 100%; border-collapse: collapse; }
        th { background-color: #a0ac90; color: white; padding: 12px; text-align: left; }
        td { padding: 12px; border-bottom: 1px solid #eee; }
        .btn-edit { padding: 8px 16px; background: #a0ac90; color: white; text-decoration: none; border-radius: 4px; }
        .btn-logout { padding: 8px 16px; background: #d9534f; color: white; text-decoration: none; border-radius: 4px; }
    </style>
</head>
<body>
    <div class="container">
        <div class="profile-header">
            <h1 style="margin: 0; color: #4a4a4a;">Hi, <?php echo htmlspecialchars($user_name); ?>!</h1>
            <div>
                <a href="edit_account.php" class="btn-edit">Edit Profile</a>
                <a href="logout.php" class="btn-logout">Logout</a>
            </div>
        </div>
        <h2 style="color: #666;">My Borrowing History</h2>
        <table>
            <thead>
                <tr><th>Book Title</th><th>Checkout Date</th><th>Due Date</th><th>Status</th></tr>
            </thead>
            <tbody>
                <?php
                $sql = "SELECT d.Title, b.TimeOut, b.TimeDueIn, b.Returned FROM Booking b 
                        JOIN Inventory i ON b.BookID = i.BookID 
                        JOIN BookDescribed d ON i.ISBN = d.ISBN 
                        WHERE b.UserID = $user_id ORDER BY b.TimeOut DESC";
                $res = $conn->query($sql);
                if ($res->num_rows > 0) {
                    while($row = $res->fetch_assoc()) {
                        $status = $row['Returned'] ? "Returned" : "Checked Out";
                        echo "<tr><td>{$row['Title']}</td><td>{$row['TimeOut']}</td><td>{$row['TimeDueIn']}</td><td>$status</td></tr>";
                    }
                } else { echo "<tr><td colspan='4'>No history found.</td></tr>"; }
                ?>
            </tbody>
        </table>
    </div>
</body>
</html>