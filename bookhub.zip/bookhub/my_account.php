<?php 
session_start(); 
if (!isset($_SESSION['user_id'])) { 
    header("Location: login.php"); 
    exit(); 
} 

include 'db_connect.php'; 

$user_id = $_SESSION['user_id'];
$user_name = $_SESSION['name'];
$message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['return_booking_id'])) {
    $booking_id = intval($_POST['return_booking_id']);
        $update_sql = "UPDATE Booking SET Returned = 1 WHERE BookingID = $booking_id AND UserID = $user_id";
    
    if ($conn->query($update_sql) === TRUE) {
        $message = "<div style='background: #d4edda; color: #155724; padding: 15px; border-radius: 6px; margin-bottom: 20px; border: 1px solid #c3e6cb;'>
                        <strong>Success!</strong> The book has been returned to the library.
                    </div>";
    } else {
        $message = "<div style='color: red; margin-bottom: 20px;'>Error processing return: " . $conn->error . "</div>";
    }
}

include 'header.php'; 
?>
<!DOCTYPE html>
<html>
<head>
    <title>My Account - BookHub</title>
    <style>
        body { font-family: 'Segoe UI', sans-serif; background-color: #ede6df; margin: 0; }
        .container { max-width: 1000px; margin: 40px auto; background: white; padding: 35px; border-radius: 12px; box-shadow: 0 4px 15px rgba(0,0,0,0.05); }
        .profile-header { display: flex; justify-content: space-between; align-items: center; border-bottom: 2px solid #a0ac90; padding-bottom: 15px; margin-bottom: 30px; }
        table { width: 100%; border-collapse: collapse; }
        th { background-color: #a0ac90; color: white; padding: 12px; text-align: left; }
        td { padding: 12px; border-bottom: 1px solid #eee; vertical-align: middle; }
        
        .btn-edit { padding: 8px 16px; background: #a0ac90; color: white; text-decoration: none; border-radius: 4px; font-weight: bold; }
        .btn-logout { padding: 8px 16px; background: #d9534f; color: white; text-decoration: none; border-radius: 4px; font-weight: bold; }
        
        .btn-return { background-color: #4a4a4a; color: white; border: none; padding: 8px 15px; border-radius: 4px; cursor: pointer; font-weight: bold; transition: 0.2s; }
        .btn-return:hover { background-color: #333; }
        .status-returned { color: green; font-weight: bold; }
    </style>
</head>
<body>
    <div class="container">
        <div class="profile-header">
            <h1 style="margin: 0; color: #4a4a4a;">Hi, <?php echo htmlspecialchars($user_name); ?>!</h1>
            <div>
                <a href="edit_account.php" class="btn-edit">Edit Profile</a>
                <a href="logout.php" class="btn-logout">Logout</a>
            </div>
        </div>
        
        <h2 style="color: #666;">My Borrowing History</h2>
        
        <?php echo $message; ?>
        
        <table>
            <thead>
                <tr>
                    <th>Book Title</th>
                    <th>Checkout Date</th>
                    <th>Due Date</th>
                    <th style="text-align: center;">Status / Action</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $sql = "SELECT b.BookingID, d.Title, b.TimeOut, b.TimeDueIn, b.Returned 
                        FROM Booking b 
                        JOIN Inventory i ON b.BookID = i.BookID 
                        JOIN BookDescribed d ON i.ISBN = d.ISBN 
                        WHERE b.UserID = $user_id 
                        ORDER BY b.Returned ASC, b.TimeOut DESC";
                
                $res = $conn->query($sql);
                
                if ($res->num_rows > 0) {
                    while($row = $res->fetch_assoc()) {
                        $formatted_out = date('d/m/Y', strtotime($row['TimeOut']));
                        $formatted_due = date('d/m/Y', strtotime($row['TimeDueIn']));

                        if ($row['Returned']) {
                            $action_html = "<span class='status-returned'>Returned</span>";
                        } else {
                            $action_html = "
                                <form method='post' style='margin: 0;'>
                                    <input type='hidden' name='return_booking_id' value='" . $row['BookingID'] . "'>
                                    <button type='submit' class='btn-return'>Return Book</button>
                                </form>";
                        }
                        
                        echo "<tr>
                                <td>" . htmlspecialchars($row['Title']) . "</td>
                                <td>$formatted_out</td>
                                <td>$formatted_due</td>
                                <td style='text-align: center;'>$action_html</td>
                              </tr>";
                    }
                } else { 
                    echo "<tr><td colspan='4'>You have not borrowed any books yet.</td></tr>"; 
                }
                ?>
            </tbody>
        </table>
    </div>
</body>
</html>