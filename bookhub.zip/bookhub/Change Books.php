<?php
include 'db_connect.php'; 
$message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['update_book'])) {
    $isbn = $conn->real_escape_string($_POST['isbn_id']);
    $field = $_POST['editField'];
    $newValue = $conn->real_escape_string($_POST['newValue']); 

    $allowed = [
        'title' => 'Title',
        'author' => 'Author',
        'published' => 'Published', //book attributes
        'genre' => 'Genre'
    ];

    if (array_key_exists($field, $allowed)) {
        $column = $allowed[$field];
        $sql = "UPDATE BookDescribed SET $column = '$newValue' WHERE ISBN = '$isbn'";
        
        if ($conn->query($sql)) {
            $message = "Changes saved
            ";
        } else { //error or success --> after submitted
            $message = "Error: " . $conn->error;
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Manage Books - BookHub</title>
    <style>
        body { font-family: Arial; background-color: #f5f5f5; text-align: center; }
        .container { width: 350px; margin: 50px auto; background: white; padding: 25px; border-radius: 10px; box-shadow: 0 4px 6px rgba(0,0,0,0.1); display: inline-block; text-align: left; }
        input, select { width: 100%; padding: 10px; margin: 10px 0; box-sizing: border-box; }
        button { width: 100%; padding: 10px; background: #333; color: white; border: none; cursor: pointer; }
    </style>
</head>
<body>

    <?php include 'header.php'; ?>

    <div class="container">
        <h2>Edit Book Details</h2>
        <p style="color: green;"><?php echo $message; ?></p>

        <form method="POST"> 
            <label>Current Book ISBN:</label>
            <input type="text" name="isbn_id" required placeholder="e.g. 123456789">

            <label>Attribute to Change:</label>
            <select name="editField" required>
                <option value="title">Title</option>
                <option value="author">Author</option>
                <option value="published">Year Published</option>
                <option value="genre">Genre</option>
            </select>

            <label>New Value:</label>
            <input type="text" name="newValue" required>

            <button type="submit" name="update_book">Apply Changes</button>
        </form>
    </div>

</body>
</html>