<!DOCTYPE html>
<html>
<head>
<title>BookHub Create Account</title>
<style>
    body {
    font-family: Arial;
    background-color: #f0fff4;
    display: flex;
    flex-direction: column; 
    justify-content: center;
    align-items: center;
    height: 100vh;
    margin: 0;
    }

    .container {
    width: 320px;
    padding: 25px;
    background: white;
    border-radius: 10px;
    text-align: center;
    box-shadow: 0 4px 6px rgba(0,0,0,0.1);
    }

    input {
    width: 100%;
    padding: 10px;
    margin: 5px 0 15px 0;
    box-sizing: border-box;
    }

    button {
    width: 100%;
    padding: 10px;
    background: #22c55e;
    color: white;
    border: none;
    cursor: pointer;
    }

    p { margin: 0; font-weight: bold; }
</style>
</head>

<body>

<?php include 'header.php'; ?>

<div class="container">
    <h2>Create Account</h2>

    <form method="post" style="text-align: left;">

    <p>First Name:</p>
    <input type="text" name="firstname" required> <!-- All of the attributes to be inputted -->

    <p>Last Name:</p>
    <input type="text" name="lastname" required>

    <p>Email:</p>
    <input type="email" name="email" required>

    <p>Password:</p>
    <input type="password" name="password" required>

    <button type="submit">Submit</button>

    </form>

    <?php
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        include 'db_connect.php';

        $firstname = $conn->real_escape_string($_POST["firstname"]);
        $lastname = $conn->real_escape_string($_POST["lastname"]);
        $email = $conn->real_escape_string($_POST["email"]);
        $password = $_POST["password"];
        $role = 'Student';

        $sql = "INSERT INTO Account (FirstName, LastName, Email, Password, Role) 
                VALUES ('$firstname', '$lastname', '$email', '$password', '$role')";

        if ($conn->query($sql)) {
            echo "<h3 style='color: green;'>Account Created Successfully!</h3>";
            echo "<a href='login.php'>Click here to login</a>";
        } else {
            echo "<h3 style='color: red;'>Error: " . $conn->error . "</h3>";
        }
    }
    ?>
</div>

</body>
</html>