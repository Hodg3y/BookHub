<!DOCTYPE html>
<html>
<head>
<title>BookHub Create Account</title>
<style>
  body {
  font-family: Arial;
  background-color: #f5f5f5;
  margin: 0;
}

/* container */
.container {
  width: 500px;
  padding: 25px;
  background: white;
  border-radius: 10px;
  text-align: center;
  margin: 40px auto;
}

/* grid layout */
.grid {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 20px;
}

/* cards */
.card {
  text-decoration: none;
  background: white;
  border: 2px solid #333;
  color: #333;
  padding: 20px;
  border-radius: 8px;
  display: block;
}

/* icons */
.card i {
  font-size: 24px;
  margin-bottom: 10px;
}
</style>
</head>

<body>

<?php include 'header.php'; ?>

<div style="text-align: center; padding-top: 20px;">
    <h2>Create Account</h2>

    <form method="post" style="display: inline-block; text-align: left;">

    <p>First Name:</p>
    <input type="text" name="firstname">

    <p>Last Name:</p>
    <input type="text" name="lastname">

    <p>Email:</p>
    <input type="email" name="email">

    <p>Password:</p>
    <input type="password" name="password">

    <br><br>

    <button type="submit">Submit</button>

    </form>

    <?php
    if ($_SERVER["REQUEST_METHOD"] == "POST") {

        $firstname = $_POST["firstname"];
        $lastname = $_POST["lastname"];
        $email = $_POST["email"];
        $password = $_POST["password"];

        echo "<h3>Account Created:</h3>";
        echo "First Name: " . $firstname . "<br>";
        echo "Last Name: " . $lastname . "<br>";
        echo "Email: " . $email . "<br>";
    }
    ?>
</div>

</body>
</html>