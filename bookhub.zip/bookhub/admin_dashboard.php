<?php 
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}
if ($_SESSION['role'] !== 'Admin' && $_SESSION['role'] !== 'Staff') {
    header("Location: my_account.php");
    exit();
}
include 'header.php'; 
?>
<!DOCTYPE html>
<html>
<head>
    <title>Admin Dashboard - BookHub</title>
    <style>
        body { font-family: 'Segoe UI', sans-serif; background-color: #ede6df; margin: 0; }
        .container { max-width: 1000px; margin: 40px auto; text-align: center; padding: 20px; }
        h2 { color: #4a4a4a; margin-bottom: 10px; }
        .welcome-msg { color: #666; margin-bottom: 40px; font-size: 1.1em; }
        .grid { display: flex; justify-content: center; gap: 25px; flex-wrap: wrap; max-width: 900px; margin: 0 auto; }
        .card { 
            text-decoration: none; background: white; padding: 30px; border: 2px solid #a0ac90; 
            border-radius: 12px; color: #444; width: 180px; transition: transform 0.2s ease;
            box-shadow: 0 4px 6px rgba(0,0,0,0.05); display: flex; flex-direction: column; align-items: center;
        }
        .card:hover { transform: translateY(-5px); box-shadow: 0 8px 15px rgba(0,0,0,0.1); background-color: #fcfcfc; }
        .card i { font-size: 40px; color: #a0ac90; margin-bottom: 15px; }
        .card strong { font-size: 16px; line-height: 1.2; }
    </style>
</head>
<body>
<main class="container">
    <h2>Staff Administration</h2>
    <p class="welcome-msg">Welcome to the management dashboard, <strong><?php echo htmlspecialchars($_SESSION['name']); ?></strong>.</p>
    <div class="grid">
        <a href="view_bookings.php" class="card"><i class="fa-solid fa-calendar-days"></i><strong>Manage Bookings</strong></a>
        <a href="view_accounts.php" class="card"><i class="fa-solid fa-users"></i><strong>Manage Users</strong></a>
        <a href="add_book.php" class="card"><i class="fa-solid fa-plus"></i><strong>Add New Book</strong></a>
        <a href="Change Books.php" class="card"><i class="fa-solid fa-book-open"></i><strong>Manage Books</strong></a>
        <a href="Reports.php" class="card"><i class="fa-solid fa-chart-line"></i><strong>System Reports</strong></a>
        <a href="View_Fines.php" class="card"><i class="fa-solid fa-file-invoice-dollar"></i><strong>Manage Fines</strong></a>
    </div>
</main>
</body>
</html>