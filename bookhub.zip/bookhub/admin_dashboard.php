<?php 
session_start();
// Check for the corrected variable name
if (!isset($_SESSION['UserID'])) {
    header("Location: login.php");
    exit();
}
//check for role
if ($_SESSION['Role'] !== 'Admin' && $_SESSION['Role'] !== 'Staff') {
    header("Location: my_account.php");
    exit();
}
include 'header.php'; 
include 'db_connect.php'; 
?>
<!DOCTYPE html>
<html>
<head>
    <title>Admin Dashboard - BookHub</title>
    <style>
        body {
        font-family: Arial;
        background-color: #f5f5f5;

        display: flex;
        justify-content: center;
        align-items: center;
        height: 100vh;
        }

        /* container */
        .container {
        width: 500px;
        padding: 25px;
        background: white;
        border-radius: 10px;
        text-align: center;
        }

        /* grid layout */
        .grid {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 20px;
        }

        /* cards */
        .card {
        text-decoration: none;
        background: white;
        border: 2px solid #333;
        color: #333;
        padding: 20px;
        border-radius: 8px;
        display: block;
        }

        /* icons */
        .card i {
        font-size: 24px;
        margin-bottom: 10px;
        }
    </style>
</head>
<body>
<main class="container">
    <h2>Staff Administration</h2> <!-- all links to other pages -->
    <p class="welcome-msg">Welcome to the admin dashboard, <?php echo htmlspecialchars(isset($_SESSION['name']) ? $_SESSION['name'] : 'Admin'); ?>.</p>
    <div class="grid">
        <a href="view_bookings.php" class="card"><i class="fa-solid fa-calendar-days"></i>Manage Bookings<</a>
        <a href="view_accounts.php" class="card"><i class="fa-solid fa-users"></i>Manage Users</a>
        <a href="add_book.php" class="card"><i class="fa-solid fa-plus"></i>Add New Book</a>
        <a href="Change Books.php" class="card"><i class="fa-solid fa-book-open"></i>Manage Books</a>
        <a href="Reports.php" class="card"><i class="fa-solid fa-chart-line"></i>System Reports</a>
        <a href="View_Fines.php" class="card"><i class="fa-solid fa-file-invoice-dollar"></i>Manage Fines</a>
    </div>
</main>
</body>
</html>