<?php
/* Config */
include 'db_connect.php'; 
$message = "";
$bookCount = 0; 

try {
    $pdo = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $bookCount = $pdo->query("SELECT COUNT(*) FROM BookDescribed")->fetchColumn();

} catch (PDOException $e) {
    $message = "Database Error: " . $e->getMessage();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Bookhub - Home</title>
</head>
<body style="margin: 0;">

    <?php include 'header.php'; ?>

    <main style="padding: 40px; max-width: 800px; margin: auto;">
        <h1 style="color: #4a4a4a;">Bookhub Dashboard</h1>

        <h2 style="color: #4a4a4a; margin-top: 30px;">Library Overview</h2>
        
        <div class="stats-card" style="background-color: white; border: 2px solid #a0ac90; border-radius: 8px; padding: 20px; text-align: center; width: 250px; box-shadow: 0 4px 6px rgba(0,0,0,0.1);">
            <p style="margin: 0; font-size: 18px; color: #666;">Total Books in System</p>
            <h3 style="font-size: 50px; margin: 10px 0 0 0; color: #a0ac90;">
                <?php echo $bookCount; ?>
            </h3>
        </div>

        <?php if(!empty($message)): ?>
            <p style="color: red;"><?php echo $message; ?></p>
        <?php endif; ?>
        
    </main>

</body>
</html>