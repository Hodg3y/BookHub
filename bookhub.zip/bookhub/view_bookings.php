<?php include 'header.php'; include 'db_connect.php'; ?>
<!DOCTYPE html>
<html>
<head>
    <title>Current Bookings - BookHub</title>
    <style>
        body { font-family: 'Segoe UI', sans-serif; background-color: #ede6df; margin: 0; }
        .container { max-width: 1000px; margin: 40px auto; background: white; padding: 30px; border-radius: 8px; box-shadow: 0 4px 6px rgba(0,0,0,0.1); }
        h2 { color: #4a4a4a; border-bottom: 2px solid #a0ac90; padding-bottom: 10px; margin-bottom: 20px; }
        table { width: 100%; border-collapse: collapse; }
        th { background-color: #a0ac90; color: white; padding: 12px; text-align: left; }
        td { padding: 12px; border-bottom: 1px solid #ddd; color: #555; }
        .status-yes { color: green; font-weight: bold; }
        .status-no { color: #d9534f; font-weight: bold; }
    </style>
</head>
<body>
    <div class="container">
        <h2>Current Library Bookings</h2>
        <table>
            <thead>
                <tr>
                    <th>Booking ID</th>
                    <th>Member Name</th>
                    <th>Book Title</th>
                    <th>Due Date</th>
                    <th>Returned</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $sql = "SELECT b.BookingID, a.FirstName, a.LastName, d.Title, b.TimeDueIn, b.Returned 
                        FROM Booking b
                        JOIN Account a ON b.UserID = a.UserID
                        JOIN Inventory i ON b.BookID = i.BookID
                        JOIN BookDescribed d ON i.ISBN = d.ISBN";
                $result = $conn->query($sql);
                if ($result->num_rows > 0) {
                    while($row = $result->fetch_assoc()) {
                        $returned = $row['Returned'] ? '<span class="status-yes">Yes</span>' : '<span class="status-no">No</span>';
                        echo "<tr>
                                <td>".$row['BookingID']."</td>
                                <td>".htmlspecialchars($row['FirstName'])." ".htmlspecialchars($row['LastName'])."</td>
                                <td>".htmlspecialchars($row['Title'])."</td>
                                <td>".$row['TimeDueIn']."</td>
                                <td>".$returned."</td>
                              </tr>";
                    }
                }
                ?>
            </tbody>
        </table>
    </div>
</body>
</html>