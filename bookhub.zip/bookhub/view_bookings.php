<?php 
session_start(); 

//login
if (!isset($_SESSION['Role']) || ($_SESSION['Role'] !== 'Admin' && $_SESSION['Role'] !== 'Staff')) {
    header("Location: login.php");
    exit();
}

include 'header.php'; 
include 'db_connect.php'; 

//check in or out when clicked
if (isset($_GET['action']) && isset($_GET['booking_id']) && isset($_GET['book_id'])) {
    $booking_id = intval($_GET['booking_id']); //security
    $book_id = intval($_GET['book_id']);
    
    if ($_GET['action'] == 'check_in') {
        //update both tables 
        $conn->query("UPDATE Booking SET Returned = 1 WHERE BookingID = $booking_id");
        $conn->query("UPDATE Inventory SET Status = 'Checked In' WHERE BookID = $book_id");
    } else {
        //mark as still out 
        $conn->query("UPDATE Booking SET Returned = 0 WHERE BookingID = $booking_id");
        $conn->query("UPDATE Inventory SET Status = 'Checked Out' WHERE BookID = $book_id");
    }
    header("Location: view_bookings.php"); 
    exit();
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Current Bookings - BookHub</title>
</head>
<body>
    <div class="container">
        <h2>Current Library Bookings</h2>
        <table>
            <thead>
                <tr>
                    <th>Booking ID</th>
                    <th>Member Name</th>
                    <th>Book Title</th>
                    <th>Due Date</th>
                    <th>Returned</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php
                //update 
                $sql = "SELECT b.BookingID, b.BookID, a.FirstName, a.LastName, d.Title, b.TimeDueIn, b.Returned 
                        FROM Booking b
                        JOIN Account a ON b.UserID = a.UserID
                        JOIN Inventory i ON b.BookID = i.BookID
                        JOIN BookDescribed d ON i.ISBN = d.ISBN";
                $result = $conn->query($sql);
                if ($result->num_rows > 0) {
                    while($row = $result->fetch_assoc()) {
                        $is_returned = $row['Returned'];
                        $status_text = $is_returned ? 'Yes' : 'No';
                        
                        //Which button to show, dependant on status
                        if ($is_returned) {
                            $button = "<a href='view_bookings.php?action=check_out&booking_id=".$row['BookingID']."&book_id=".$row['BookID']."' class='btn btn-checkout'>Mark as Checked Out</a>";
                        } else {
                            $button = "<a href='view_bookings.php?action=check_in&booking_id=".$row['BookingID']."&book_id=".$row['BookID']."' class='btn btn-checkin'>Mark as Checked In</a>";
                        }

                        echo "<tr>
                                <td>".$row['BookingID']."</td>
                                <td>".htmlspecialchars($row['FirstName'])." ".htmlspecialchars($row['LastName'])."</td>
                                <td>".htmlspecialchars($row['Title'])."</td>
                                <td>".$row['TimeDueIn']."</td>
                                <td>".$status_text."</td>
                                <td>".$button."</td>
                              </tr>";
                    }
                }
                ?>
            </tbody>
        </table>
    </div>
</body>
</html>