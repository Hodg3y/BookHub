<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

include 'header.php';
include 'db_connect.php';

$user_id = $_SESSION['user_id'];
$message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['take_book_id'])) {
    $book_id = intval($_POST['take_book_id']);

    $check_sql = "SELECT * FROM Booking WHERE BookID = $book_id AND Returned = 0";
    $check_res = $conn->query($check_sql);
    
    if ($check_res->num_rows == 0) {
        $checkout_sql = "INSERT INTO Booking (UserID, BookID, TimeOut, TimeDueIn, Returned) 
                         VALUES ($user_id, $book_id, CURDATE(), DATE_ADD(CURDATE(), INTERVAL 14 DAY), 0)";
                         
        if ($conn->query($checkout_sql) === TRUE) {
            $message = "<div style='background: #d4edda; color: #155724; padding: 15px; border-radius: 6px; margin-bottom: 20px; border: 1px solid #c3e6cb;'>
                            <strong>Success!</strong> The book has been added to your account.
                        </div>";
        } else {
            $message = "<p style='color: red;'>Error processing booking: " . $conn->error . "</p>";
        }
    } else {
        $message = "<p style='color: red;'>Sorry, this specific book was just checked out.</p>";
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Take Out a Book</title>
    <style>
        body { font-family: 'Segoe UI', sans-serif; background-color: #ede6df; margin: 0; }
        .container { max-width: 800px; margin: 40px auto; background: white; padding: 30px; border-radius: 12px; box-shadow: 0 4px 15px rgba(0,0,0,0.05); }
        h1, h2 { color: #4a4a4a; }
        .search-box { display: flex; gap: 10px; margin-bottom: 30px; }
        .search-box input { flex-grow: 1; padding: 12px; border: 1px solid #ddd; border-radius: 6px; }
        .btn-search { background-color: #4a4a4a; color: white; border: none; padding: 12px 25px; border-radius: 6px; cursor: pointer; font-weight: bold; }
        .book-card { background: #fcfcfc; border: 1px solid #ddd; padding: 20px; border-radius: 8px; margin-bottom: 15px; display: flex; justify-content: space-between; align-items: center; border-left: 5px solid #a0ac90; }
        .book-info h3 { margin: 0 0 5px 0; color: #333; }
        .book-info p { margin: 0; color: #666; font-size: 14px; }
        .btn-take { background-color: #a0ac90; color: white; border: none; padding: 10px 20px; border-radius: 4px; cursor: pointer; font-weight: bold; transition: 0.2s; }
        .btn-take:hover { background-color: #8e9a7e; }
    </style>
</head>
<body>
    <div class="container">
        <h1>Borrow Books</h1>
        
        <?php echo $message; ?>
        
        <form method="post" class="search-box">
            <input type="text" name="search" placeholder="Search title or author..." value="<?php echo isset($_POST['search']) ? htmlspecialchars($_POST['search']) : ''; ?>">
            <button type="submit" class="btn-search">Search Inventory</button>
        </form>

        <h2>Available Inventory</h2>
        
        <?php
        $search_query = "";
        if (isset($_POST['search']) && trim($_POST['search']) != '') {
            $term = $conn->real_escape_string(trim($_POST['search']));
            $search_query = " AND (d.Title LIKE '%$term%' OR d.Author LIKE '%$term%')";
        }
        
        $sql = "SELECT i.BookID, d.Title, d.Author, d.Genre 
                FROM Inventory i
                JOIN BookDescribed d ON i.ISBN = d.ISBN
                WHERE i.BookID NOT IN (SELECT BookID FROM Booking WHERE Returned = 0)
                $search_query
                ORDER BY d.Title ASC";
                
        $result = $conn->query($sql);
        
        if ($result->num_rows > 0) {
            while($row = $result->fetch_assoc()) {
                echo "<div class='book-card'>
                        <div class='book-info'>
                            <h3>" . htmlspecialchars($row['Title']) . "</h3>
                            <p><strong>Author:</strong> " . htmlspecialchars($row['Author']) . " | <strong>Genre:</strong> " . htmlspecialchars($row['Genre']) . " | <strong>ID:</strong> " . $row['BookID'] . "</p>
                        </div>
                        <form method='post' style='margin: 0;'>
                            <input type='hidden' name='take_book_id' value='" . $row['BookID'] . "'>
                            <button type='submit' class='btn-take'>Check Out</button>
                        </form>
                      </div>";
            }
        } else {
            echo "<p style='color: #666;'>No available books match your search. They might all be checked out!</p>";
        }
        ?>
    </div>
</body>
</html>