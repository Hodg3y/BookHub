<?php 
session_start(); 
include 'header.php'; 
include 'db_connect.php'; 

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    if (isset($_POST["search"])) { 
        $search = $_POST["search"];
        echo "<p>You searched for: " . htmlspecialchars($search) . "</p>";
    }

    if (isset($_POST["book_id"])) {
        $book_id = $_POST["book_id"]; 
        $user_id = $_SESSION['UserID'];

        //dates
        $date_out = date('Y-m-d');
        $date_due = date('Y-m-d', strtotime('+14 days'));

        
        //save data
        $insert_sql = "INSERT INTO Booking (UserID, BookID, TimeOut, TimeDueIn, Returned) 
                       VALUES ($user_id, $book_id, '$date_out', '$date_due', 0)";
        
        $update_sql = "UPDATE Inventory SET Status = 'Checked Out' WHERE BookID = $book_id";

        if ($conn->query($insert_sql) && $conn->query($update_sql)) {
            echo "<h3 style='color: green;'>Success! You took out the book.</h3>";
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Take Out a Book</title>
    <style>
        body { font-family: Arial; background-color: #eff6ff; text-align: center; }
        .book { width: 300px; margin: 20px auto; padding: 15px; background: white; border-radius: 10px; border: 1px solid #ddd; }
        button { padding: 10px; background: #2563eb; color: white; border: none; cursor: pointer; border-radius: 5px; }
    </style>
</head>
<body style="margin: 0;">
    <div style="padding: 20px;">
        <h1>Take Out a Book</h1>
        <p>Search for available books:</p>
        <form method="post">
            <input type="text" name="search" placeholder="Enter book name">
            <button type="submit">Search</button>
        </form>

        <h2>Available Books</h2>
        <?php
        // Load the books data - only load the books not currently taken out
        $search_term = isset($_POST['search']) ? $conn->real_escape_string($_POST['search']) : "";
        
        $sql = "SELECT i.BookID, d.Title, d.Author 
                FROM Inventory i
                JOIN BookDescribed d ON i.ISBN = d.ISBN
                WHERE i.Status = 'Checked In' AND d.Title LIKE '%$search_term%'";

        $result = $conn->query($sql);

        if ($result && $result->num_rows > 0) {
            while($row = $result->fetch_assoc()) {
                echo "<div class='book'>";
                echo "<p><strong>Title:</strong> " . htmlspecialchars($row['Title']) . "</p>";
                echo "<p><strong>Author:</strong> " . htmlspecialchars($row['Author']) . "</p>";
                // Have the buttons to take out that book
                echo "<form method='post'>";
                echo "<input type='hidden' name='book_id' value='" . $row['BookID'] . "'>";
                echo "<button type='submit'>Take Out</button>";
                echo "</form>";
                echo "</div>";
            }
        } else {
            echo "<p>No available books found.</p>";
        }
        ?>
    </div>
</body>
</html>