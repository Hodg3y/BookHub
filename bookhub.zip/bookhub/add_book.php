<?php include 'header.php'; include 'db_connect.php'; ?>
<!DOCTYPE html>
<html>
<head>
    <title>Add New Book - BookHub</title>
    <style>
        body { font-family: 'Segoe UI', sans-serif; background-color: #ede6df; margin: 0; }
        .form-container { max-width: 500px; margin: 40px auto; background: white; padding: 30px; border-radius: 8px; box-shadow: 0 4px 6px rgba(0,0,0,0.1); }
        h2 { color: #4a4a4a; text-align: center; margin-bottom: 25px; }
        .input-group { margin-bottom: 15px; }
        label { display: block; margin-bottom: 5px; color: #666; font-weight: bold; }
        input, textarea { width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 4px; box-sizing: border-box; }
        input[type="submit"] { background-color: #a0ac90; color: white; border: none; padding: 12px; cursor: pointer; font-weight: bold; margin-top: 10px; }
        input[type="submit"]:hover { background-color: #8e9a7e; }
        .status-msg { text-align: center; margin-bottom: 15px; }
    </style>
</head>
<body>
    <div class="form-container">
        <h2>Enter New Book Details</h2>
        <?php
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            $isbn = $conn->real_escape_string($_POST['isbn']);
            $title = $conn->real_escape_string($_POST['title']);
            $author = $conn->real_escape_string($_POST['author']);
            $year = intval($_POST['published']);
            $genre = $conn->real_escape_string($_POST['genre']);
            $desc = $conn->real_escape_string($_POST['description']);

            $sql = "INSERT INTO BookDescribed (ISBN, Title, Author, Published, Genre, Description) 
                    VALUES ('$isbn', '$title', '$author', $year, '$genre', '$desc')";

            if ($conn->query($sql) === TRUE) {
                echo "<p class='status-msg' style='color: green;'>✔ Book successfully added to catalog.</p>";
            } else {
                echo "<p class='status-msg' style='color: red;'>✘ Error: " . $conn->error . "</p>";
            }
        }
        ?>
        <form action="add_book.php" method="post">
            <div class="input-group">
                <label>ISBN</label>
                <input type="text" name="isbn" required>
            </div>
            <div class="input-group">
                <label>Title</label>
                <input type="text" name="title" required>
            </div>
            <div class="input-group">
                <label>Author</label>
                <input type="text" name="author" required>
            </div>
            <div class="input-group">
                <label>Year Published</label>
                <input type="number" name="published" required>
            </div>
            <div class="input-group">
                <label>Genre</label>
                <input type="text" name="genre" required>
            </div>
            <div class="input-group">
                <label>Description</label>
                <textarea name="description" rows="4"></textarea>
            </div>
            <input type="submit" value="Add Book to System">
        </form>
    </div>
</body>
</html>