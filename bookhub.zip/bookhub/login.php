<?php
session_start();
include 'db_connect.php';

$error = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $conn->real_escape_string($_POST["email"]);
    $password = $_POST["password"]; 
    
    //Check database for matching email and password
    $sql = "SELECT UserID, FirstName, Role FROM Account WHERE Email = '$email' AND Password = '$password'";
    $result = $conn->query($sql);

    if ($result && $result->num_rows == 1) {
        $user = $result->fetch_assoc();
        
        $_SESSION['UserID'] = $user['UserID'];     
        $_SESSION['FirstName'] = $user['FirstName'];
        $_SESSION['name'] = $user['FirstName'];
        $_SESSION['Role'] = $user['Role'];           

        header("Location: my_account.php");
        exit();
    } else {
        //errors
        $error = "Invalid email or password";
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>BookHub Login</title>
    <style>
        body {
        font-family: Arial;
        background-color: #eef3ff;
        display: flex;
        flex-direction: column; /* Fixed alignment to show header correctly */
        justify-content: center;
        align-items: center;
        height: 100vh;
        margin: 0;
        }

        .container {
        width: 320px;
        padding: 25px;
        background: white;
        border-radius: 10px;
        text-align: center;
        box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        }

        input {
        width: 100%;
        padding: 10px;
        margin: 10px 0;
        box-sizing: border-box; /* Ensures padding doesn't break width */
        }

        button {
        width: 100%;
        padding: 10px;
        background: #3b82f6;
        color: white;
        border: none;
        cursor: pointer;
        }
        
        .test-acc { font-size: 0.8em; color: #666; margin-top: 15px; }
    </style>
</head>
<body>
    
    <?php include 'header.php'; ?>

    <div class="container">
        <h2>Login to BookHub</h2>

        <?php if($error): ?>
            <p style="color: red;"><?php echo $error; ?></p>
        <?php endif; ?>

        <form method="post">
            <div style="text-align: left;">
                <label>Email Address</label>
                <input type="email" name="email" required>
            </div>
            <div style="text-align: left;">
                <label>Password</label>
                <input type="password" name="password" required>
            </div>
            <button type="submit">Login</button>
        </form>
        
        <div style="margin-top: 15px;">
            Don't have an account? <a href="create_account.php">Create one here</a>.
        </div>

        <div class="test-acc">Test Account: JohnSmith@gmail.com / pass1</div>
    </div>

</body>
</html>