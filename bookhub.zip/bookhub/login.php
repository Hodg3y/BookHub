<?php
session_start(); 
include 'db_connect.php';

$error = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $conn->real_escape_string($_POST["email"]);
    $password = $_POST["password"]; 

    $sql = "SELECT UserID, FirstName, Role FROM Account WHERE Email = '$email' AND Password = '$password'";
    $result = $conn->query($sql);

    if ($result->num_rows == 1) {
        $user = $result->fetch_assoc();
        $_SESSION['user_id'] = $user['UserID'];
        $_SESSION['name'] = $user['FirstName'];
        $_SESSION['role'] = $user['Role'];
        header("Location: my_account.php");
        exit();
    } else {
        $error = "Invalid email or password.";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>BookHub Login</title>
</head>
<body style="margin: 0;">

    <?php include 'header.php'; ?>

    <div style="padding: 40px; text-align: center; max-width: 400px; margin: auto;">
        <h2 style="color: #4a4a4a;">Login to BookHub</h2>

        <?php if($error): ?>
            <p style="color: red;"><?php echo $error; ?></p>
        <?php endif; ?>

        <form method="post" style="display: flex; flex-direction: column; text-align: left; background: white; padding: 20px; border: 1px solid #a0ac90; border-radius: 8px;">
            <label style="margin-bottom: 5px;">Email:</label>
            <input type="email" name="email" required style="padding: 10px; margin-bottom: 15px; border: 1px solid #ccc; border-radius: 4px;">

            <label style="margin-bottom: 5px;">Password:</label>
            <input type="password" name="password" required style="padding: 10px; margin-bottom: 20px; border: 1px solid #ccc; border-radius: 4px;">

            <button type="submit" style="padding: 10px; background-color: #a0ac90; color: white; border: none; cursor: pointer; border-radius: 4px; font-weight: bold;">Login</button>
        </form>
        
        <p style="font-size: 12px; color: #666; margin-top: 20px;">Test Account: JohnSmith@gmail.com / pass1</p>
    </div>

</body>
</html>