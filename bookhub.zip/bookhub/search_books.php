<?php include 'header.php'; include 'db_connect.php'; ?>
<!DOCTYPE html>
<html>
<head>
    <title>Search Catalog</title>
    <style>
        body { font-family: 'Segoe UI', sans-serif; background-color: #ede6df; margin: 0; }
        .container { max-width: 900px; margin: 40px auto; padding: 20px; }
        .search-bar { display: flex; gap: 10px; background: white; padding: 20px; border-radius: 8px; box-shadow: 0 4px 6px rgba(0,0,0,0.05); margin-bottom: 30px; }
        select, input[type="text"] { padding: 12px; border: 1px solid #ddd; border-radius: 4px; }
        button { background: #a0ac90; color: white; border: none; padding: 12px 25px; border-radius: 4px; cursor: pointer; font-weight: bold; }
        .book-result { background: white; padding: 20px; border-radius: 8px; margin-bottom: 15px; border-left: 6px solid #a0ac90; box-shadow: 0 2px 5px rgba(0,0,0,0.05); }
        .book-result h3 { margin: 0 0 5px 0; color: #333; }
        .book-meta { font-size: 14px; color: #666; margin-bottom: 10px; }
    </style>
</head>
<body>
    <div class="container">
        <h2 style="color: #4a4a4a;">Find a Book</h2>
        <form class="search-bar" method="GET">
            <select name="filter">
                <option value="all" <?php if(isset($_GET['filter']) && $_GET['filter'] == 'all') echo 'selected'; ?>>All Fields</option>
                <option value="title" <?php if(isset($_GET['filter']) && $_GET['filter'] == 'title') echo 'selected'; ?>>Title</option>
                <option value="author" <?php if(isset($_GET['filter']) && $_GET['filter'] == 'author') echo 'selected'; ?>>Author</option>
            </select>
            <input type="text" name="query" placeholder="Enter keywords..." value="<?php echo isset($_GET['query']) ? htmlspecialchars($_GET['query']) : ''; ?>" style="flex-grow: 1;">
            <button type="submit">Search</button>
        </form>

        <div id="results">
            <?php
            if (isset($_GET['query']) && trim($_GET['query']) !== '') {
                $search = $conn->real_escape_string(trim($_GET['query']));
                $filter = $_GET['filter'];
                $sql = ($filter == 'all') ? "SELECT * FROM BookDescribed WHERE Title LIKE '%$search%' OR Author LIKE '%$search%'" : "SELECT * FROM BookDescribed WHERE $filter LIKE '%$search%'";
            } else {
                $sql = "SELECT * FROM BookDescribed";
            }

            $result = $conn->query($sql);
            if ($result->num_rows > 0) {
                while($row = $result->fetch_assoc()) {
                    echo "<div class='book-result'>";
                    echo "<h3>" . htmlspecialchars($row['Title']) . "</h3>";
                    echo "<div class='book-meta'><strong>Author:</strong> " . htmlspecialchars($row['Author']) . " | <strong>Genre:</strong> " . htmlspecialchars($row['Genre']) . "</div>";
                    echo "<p style='margin:0;'>" . htmlspecialchars($row['Description']) . "</p>";
                    echo "</div>";
                }
            } else { echo "<p>No books found.</p>"; }
            ?>
        </div>
    </div>
</body>
</html>