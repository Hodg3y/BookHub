<?php
session_start();

if (!isset($_SESSION['UserID'])) { //connect
    header("Location: login.php");
    exit();
}

include 'db_connect.php';
include 'header.php';

$user_id = $_SESSION['UserID'];
$message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $first_name = $conn->real_escape_string($_POST['FirstName']);
    $last_name = $conn->real_escape_string($_POST['LastName']); //get data
    $email = $conn->real_escape_string($_POST['Email']);

    $update_sql = "UPDATE Account SET FirstName = '$first_name', LastName = '$last_name', Email = '$email' WHERE UserID = $user_id"; //updating the table

    if ($conn->query($update_sql)) {
        $_SESSION['FirstName'] = $first_name; 
        $_SESSION['name'] = $first_name;
        $message = "Account updated successfully!";
    } else {
        $message = "Error updating account: " . $conn->error;
    }
}

$sql = "SELECT FirstName, LastName, Email FROM Account WHERE UserID = $user_id";
$result = $conn->query($sql); //get data
$user = $result->fetch_assoc();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Account - BookHub</title>
    <style>
        body { font-family: 'Segoe UI', sans-serif; background-color: #ede6df; margin: 0; }
        .container { max-width: 600px; margin: 50px auto; background: white; padding: 30px; border-radius: 8px; box-shadow: 0 4px 6px rgba(0,0,0,0.1); }
        input { width: 100%; padding: 10px; margin: 10px 0; border: 1px solid #ddd; border-radius: 4px; box-sizing: border-box; }
        button { background: #a0ac90; color: white; border: none; padding: 12px 20px; border-radius: 4px; cursor: pointer; width: 100%; font-weight: bold; }
        .msg { padding: 10px; margin-bottom: 20px; border-radius: 4px; text-align: center; }
        .success { background: #d4edda; color: #155724; }
    </style>
</head>
<body>
    <div class="container">
        <h2>Edit Account Information</h2>

        <?php if ($message): ?>
            <div class="msg success"><?php echo $message; ?></div>
        <?php endif; ?>

        <form method="post">
            <label>First Name</label>
            <input type="text" name="FirstName" value="<?php echo htmlspecialchars($user['FirstName']); ?>" required>

            <label>Last Name</label>
            <input type="text" name="LastName" value="<?php echo htmlspecialchars($user['LastName']); ?>" required>

            <label>Email Address</label>
            <input type="email" name="Email" value="<?php echo htmlspecialchars($user['Email']); ?>" required>

            <button type="submit">Save Changes</button>
        </form>
        <p style="text-align: center;"><a href="my_account.php" style="color: #666;">Back to Profile</a></p>
    </div>
</body>
</html>