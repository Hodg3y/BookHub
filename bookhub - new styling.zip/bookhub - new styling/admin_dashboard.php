<?php 
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}
if ($_SESSION['role'] !== 'Admin' && $_SESSION['role'] !== 'Staff') {
    header("Location: my_account.php");
    exit();
}
include 'header.php'; 
?>
<!DOCTYPE html>
<html>
<head>
    <title>Admin Dashboard - BookHub</title>
    <style>
        body {
        font-family: Arial;
        background-color: #f5f5f5;

        display: flex;
        justify-content: center;
        align-items: center;
        height: 100vh;
        }

        /* container */
        .container {
        width: 500px;
        padding: 25px;
        background: white;
        border-radius: 10px;
        text-align: center;
        }

        /* grid layout */
        .grid {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 20px;
        }

        /* cards */
        .card {
        text-decoration: none;
        background: white;
        border: 2px solid #333;
        color: #333;
        padding: 20px;
        border-radius: 8px;
        display: block;
        }

        /* icons */
        .card i {
        font-size: 24px;
        margin-bottom: 10px;
        }
    </style>
</head>
<body>
<main class="container">
    <h2>Staff Administration</h2>
    <p class="welcome-msg">Welcome to the management dashboard, <strong><?php echo htmlspecialchars($_SESSION['name']); ?></strong>.</p>
    <div class="grid">
        <a href="view_bookings.php" class="card"><i class="fa-solid fa-calendar-days"></i><strong>Manage Bookings</strong></a>
        <a href="view_accounts.php" class="card"><i class="fa-solid fa-users"></i><strong>Manage Users</strong></a>
        <a href="add_book.php" class="card"><i class="fa-solid fa-plus"></i><strong>Add New Book</strong></a>
        <a href="Change Books.php" class="card"><i class="fa-solid fa-book-open"></i><strong>Manage Books</strong></a>
        <a href="Reports.php" class="card"><i class="fa-solid fa-chart-line"></i><strong>System Reports</strong></a>
        <a href="View_Fines.php" class="card"><i class="fa-solid fa-file-invoice-dollar"></i><strong>Manage Fines</strong></a>
    </div>
</main>
</body>
</html>