<?php
session_start();
include 'db_connect.php';

$error = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $conn->real_escape_string($_POST["email"]);
    $password = $_POST["password"]; 
    $sql = "SELECT UserID, FirstName, Role FROM Account WHERE Email = '$email' AND Password = '$password'";
    $result = $conn->query($sql);

    if ($result->num_rows == 1) {
        $user = $result->fetch_assoc();

        $_SESSION['user_id'] = $user['UserID'];
        $_SESSION['name'] = $user['FirstName'];
        $_SESSION['role'] = $user['Role'];

        header("Location: my_account.php");
        exit();
    } else {
        $error = "Invalid email or password.";
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>BookHub Login</title>
    <style>
        body {
        font-family: Arial;
        background-color: #eef3ff;
        display: flex;
        justify-content: center;
        align-items: center;
        height: 100vh;
        }

        .container {
        width: 320px;
        padding: 25px;
        background: white;
        border-radius: 10px;
        text-align: center;
        }

        input {
        width: 100%;
        padding: 10px;
        margin: 10px 0;
        }

        button {
        width: 100%;
        padding: 10px;
        background: #3b82f6;
        color: white;
        border: none;
        }
    </style>
</head>
<body>
    
    <?php include 'header.php'; ?>

    <div class="container">
        <h2>Login to BookHub</h2>

        <?php if($error): ?>
            <p style="color: red;"><?php echo $error; ?></p>
        <?php endif; ?>

        <form method="post">
            <div class="input-group">
                <label>Email Address</label>
                <input type="email" name="email" required>
            </div>
            <div class="input-group">
                <label>Password</label>
                <input type="password" name="password" required>
            </div>
            <button type="submit">Login</button>
        </form>
        
        <div class="signup-link">
            Don't have an account? <a href="create_account.php">Create one here</a>.
        </div>

        <div class="test-acc">Test Account: JohnSmith@gmail.com / pass1</div>
    </div>

</body>
</html>