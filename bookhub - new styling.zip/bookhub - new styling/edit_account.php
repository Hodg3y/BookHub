<!DOCTYPE html>
<html>
<head>
    <title>Edit Account</title>
    <style>
        body {
        font-family: Arial;
        background-color: #fff7ed;
        display: flex;
        justify-content: center;
        align-items: center;
        height: 100vh;
        }

        .container {
        width: 320px;
        padding: 25px;
        background: white;
        border-radius: 10px;
        text-align: center;
        }

        input {
        width: 100%;
        padding: 10px;
        margin: 10px 0;
        }

        button {
        width: 100%;
        padding: 10px;
        background: #f97316;
        color: white;
        border: none;
        }
    </style>
</head>
<body style="margin: 0;">

    <?php include 'header.php'; ?>

    <div style="padding: 20px;">
        <h1>Edit Account</h1>

        <p>Change your account details below:</p>

        <form method="post">
            <label>Username:</label><br>
            <input type="text" name="username"><br><br>

            <label>Password:</label><br>
            <input type="password" name="password"><br><br>

            <label>Email:</label><br>
            <input type="email" name="email"><br><br>

            <label>Age:</label><br>
            <input type="number" name="age"><br><br>

            <button type="submit">Save Changes</button>
        </form>

        <?php
        if ($_SERVER["REQUEST_METHOD"] == "POST") {

            $username = $_POST["username"];
            $password = $_POST["password"];
            $email = $_POST["email"];
            $age = $_POST["age"];

            echo "<h3>Updated Details:</h3>";
            echo "Username: " . $username . "<br>";
            echo "Password: " . $password . "<br>";
            echo "Email: " . $email . "<br>";
            echo "Age: " . $age;
        }
        ?>
    </div>

</body>
</html>