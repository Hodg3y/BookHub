<!DOCTYPE html>
<html>
<head>
<title>BookHub Create Account</title>
<style>
    body {
    font-family: Arial;
    background-color: #f0fff4;
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
    }

    .container {
    width: 320px;
    padding: 25px;
    background: white;
    border-radius: 10px;
    text-align: center;
    }

    input {
    width: 100%;
    padding: 10px;
    margin: 10px 0;
    }

    button {
    width: 100%;
    padding: 10px;
    background: #22c55e;
    color: white;
    border: none;
    }
</style>
</head>

<body>

<?php include 'header.php'; ?>

<div style="text-align: center; padding-top: 20px;">
    <h2>Create Account</h2>

    <form method="post" style="display: inline-block; text-align: left;">

    <p>First Name:</p>
    <input type="text" name="firstname">

    <p>Last Name:</p>
    <input type="text" name="lastname">

    <p>Email:</p>
    <input type="email" name="email">

    <p>Password:</p>
    <input type="password" name="password">

    <br><br>

    <button type="submit">Submit</button>

    </form>

    <?php
    if ($_SERVER["REQUEST_METHOD"] == "POST") {

        $firstname = $_POST["firstname"];
        $lastname = $_POST["lastname"];
        $email = $_POST["email"];
        $password = $_POST["password"];

        echo "<h3>Account Created:</h3>";
        echo "First Name: " . $firstname . "<br>";
        echo "Last Name: " . $lastname . "<br>";
        echo "Email: " . $email . "<br>";
    }
    ?>
</div>

</body>
</html>