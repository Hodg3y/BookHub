<?php include 'header.php'; include 'db_connect.php'; ?>
<!DOCTYPE html>
<html>
<head>
    <title>Add New Book - BookHub</title>
    <style>
        body {
        font-family: Arial;
        background-color: #f5f5f5;

        display: flex;
        justify-content: center;
        align-items: center;
        height: 100vh;
        }

        /* main container */
        .container {
        width: 350px;
        padding: 25px;
        background: white;
        border-radius: 10px;
        }

        /* labels */
        label {
        display: block;
        margin: 10px 0 5px;
        }

        /* inputs */
        input, textarea {
        width: 100%;
        padding: 8px;
        border: 1px solid #ccc;
        border-radius: 5px;
        margin-bottom: 10px;
        }

        /* button */
        input[type="submit"] {
        background: #333;
        color: white;
        border: none;
        padding: 10px;
        cursor: pointer;
        }
    </style>
</head>
<body>
    <div class="form-container">
        <h2>Enter New Book Details</h2>
        <?php
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            $isbn = $conn->real_escape_string($_POST['isbn']);
            $title = $conn->real_escape_string($_POST['title']);
            $author = $conn->real_escape_string($_POST['author']);
            $year = intval($_POST['published']);
            $genre = $conn->real_escape_string($_POST['genre']);
            $desc = $conn->real_escape_string($_POST['description']);

            $sql = "INSERT INTO BookDescribed (ISBN, Title, Author, Published, Genre, Description) 
                    VALUES ('$isbn', '$title', '$author', $year, '$genre', '$desc')";

            if ($conn->query($sql) === TRUE) {
                echo "<p class='status-msg' style='color: green;'>✔ Book successfully added to catalog.</p>";
            } else {
                echo "<p class='status-msg' style='color: red;'>✘ Error: " . $conn->error . "</p>";
            }
        }
        ?>
        <form action="add_book.php" method="post">
            <div class="input-group">
                <label>ISBN</label>
                <input type="text" name="isbn" required>
            </div>
            <div class="input-group">
                <label>Title</label>
                <input type="text" name="title" required>
            </div>
            <div class="input-group">
                <label>Author</label>
                <input type="text" name="author" required>
            </div>
            <div class="input-group">
                <label>Year Published</label>
                <input type="number" name="published" required>
            </div>
            <div class="input-group">
                <label>Genre</label>
                <input type="text" name="genre" required>
            </div>
            <div class="input-group">
                <label>Description</label>
                <textarea name="description" rows="4"></textarea>
            </div>
            <input type="submit" value="Add Book to System">
        </form>
    </div>
</body>
</html>