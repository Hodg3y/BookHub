<!DOCTYPE html>
<html>
<head>
    <title>Take Out a Book</title>
    <style>
        body {
        font-family: Arial;
        background-color: #eff6ff;
        text-align: center;
        }

        .book {
        width: 300px;
        margin: 20px auto;
        padding: 15px;
        background: white;
        border-radius: 10px;
        }

        button {
        padding: 10px;
        background: #2563eb;
        color: white;
        border: none;
        }
    </style>
</head>
<body style="margin: 0;">

    <?php include 'header.php'; ?>

    <div style="padding: 20px;">
        <h1>Take Out a Book</h1>

        <p>Search for available books:</p>

        <form method="post">
            <input type="text" name="search" placeholder="Enter book name">
            <button type="submit">Search</button>
        </form>

        <h2>Available Books</h2>

        <form method="post">
            <div>
                <p>Title: 1984</p>
                <p>Author: George Orwell</p>
                <button type="submit" name="book" value="1984">Take Out</button>
            </div>

            <br>

            <div>
                <p>Title: Pride and Prejudice</p>
                <p>Author: Jane Austen</p>
                <button type="submit" name="book" value="Pride and Prejudice">Take Out</button>
            </div>
        </form>

        <?php
        if ($_SERVER["REQUEST_METHOD"] == "POST") {

            if (isset($_POST["search"])) {
                $search = $_POST["search"];
                echo "<p>You searched for: " . $search . "</p>";
            }

            if (isset($_POST["book"])) {
                $book = $_POST["book"];
                echo "<h3>You took out: " . $book . "</h3>";
            }
        }
        ?>
    </div>

</body>
</html>