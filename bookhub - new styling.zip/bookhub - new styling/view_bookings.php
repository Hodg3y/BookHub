<?php include 'header.php'; include 'db_connect.php'; ?>
<!DOCTYPE html>
<html>
<head>
    <title>Current Bookings - BookHub</title>
    <style>
        body {
        font-family: Arial;
        background-color: #f9fafb;
        text-align: center;
        }

        .booking {
        width: 300px;
        margin: 20px auto;
        padding: 15px;
        background: white;
        border-radius: 10px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Current Library Bookings</h2>
        <table>
            <thead>
                <tr>
                    <th>Booking ID</th>
                    <th>Member Name</th>
                    <th>Book Title</th>
                    <th>Due Date</th>
                    <th>Returned</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $sql = "SELECT b.BookingID, a.FirstName, a.LastName, d.Title, b.TimeDueIn, b.Returned 
                        FROM Booking b
                        JOIN Account a ON b.UserID = a.UserID
                        JOIN Inventory i ON b.BookID = i.BookID
                        JOIN BookDescribed d ON i.ISBN = d.ISBN";
                $result = $conn->query($sql);
                if ($result->num_rows > 0) {
                    while($row = $result->fetch_assoc()) {
                        $returned = $row['Returned'] ? '<span class="status-yes">Yes</span>' : '<span class="status-no">No</span>';
                        echo "<tr>
                                <td>".$row['BookingID']."</td>
                                <td>".htmlspecialchars($row['FirstName'])." ".htmlspecialchars($row['LastName'])."</td>
                                <td>".htmlspecialchars($row['Title'])."</td>
                                <td>".$row['TimeDueIn']."</td>
                                <td>".$returned."</td>
                              </tr>";
                    }
                }
                ?>
            </tbody>
        </table>
    </div>
</body>
</html>